function cnome() {
    let n = document.getElementById("nome").value 
    alert("bem vinde ai JS: "+ n)
}

function ola() {
    console.log("ola JS2")
    alert("meu front-end")
}
 

